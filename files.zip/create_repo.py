import requests
import os

token = os.getenv('GITHUB_TOKEN')
headers = {
    'Authorization': f'token {token}',
    'Accept': 'application/vnd.github.v3+json',
}

data = {
    'name': 'my-new-repo',
    'private': False,
    'description': 'My new repository'
}

response = requests.post('https://api.github.com/user/repos', headers=headers, json=data)

if response.status_code == 201:
    print('Repository created successfully.')
else:
    print('Failed to create repository:', response.json())